import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Unauthorized - clear token and redirect to login
      localStorage.removeItem('authToken');
      localStorage.removeItem('adminUser');
      if (window.location.pathname.startsWith('/admin') && window.location.pathname !== '/admin/login') {
        window.location.href = '/admin/login';
      }
    }
    return Promise.reject(error);
  }
);

// ==================== VISITOR APIs ====================

/**
 * Submit visitor form
 * @param {Object} visitorData - Visitor information
 * @returns {Promise} API response
 */
export const submitVisitorForm = async (visitorData) => {
  try {
    const response = await apiClient.post('/api/visitors', {
      ...visitorData,
      checkin_time: new Date().toISOString(),
    });
    return { success: true, data: response.data };
  } catch (error) {
    console.error('Error submitting visitor form:', error);
    return {
      success: false,
      error: error.response?.data?.message || 'Failed to submit visitor form. Please try again.',
    };
  }
};

// ==================== ADMIN APIs ====================

/**
 * Admin login
 * @param {string} email - Admin email
 * @param {string} password - Admin password
 * @returns {Promise} API response with token
 */
export const adminLogin = async (email, password) => {
  try {
    const response = await apiClient.post('/api/admin/login', { email, password });
    return { success: true, data: response.data };
  } catch (error) {
    console.error('Error during admin login:', error);
    return {
      success: false,
      error: error.response?.data?.message || 'Invalid credentials. Please try again.',
    };
  }
};

/**
 * Get all visitors with optional filters
 * @param {Object} params - Query parameters (search, purpose, startDate, endDate, page, limit)
 * @returns {Promise} API response with visitors list
 */
export const getVisitors = async (params = {}) => {
  try {
    const response = await apiClient.get('/api/admin/visitors', { params });
    return { success: true, data: response.data };
  } catch (error) {
    console.error('Error fetching visitors:', error);
    return {
      success: false,
      error: error.response?.data?.message || 'Failed to fetch visitors. Please try again.',
    };
  }
};

/**
 * Get visitor by ID
 * @param {number} id - Visitor ID
 * @returns {Promise} API response with visitor details
 */
export const getVisitorById = async (id) => {
  try {
    const response = await apiClient.get(`/api/admin/visitors/${id}`);
    return { success: true, data: response.data };
  } catch (error) {
    console.error('Error fetching visitor:', error);
    return {
      success: false,
      error: error.response?.data?.message || 'Failed to fetch visitor details.',
    };
  }
};

/**
 * Delete visitor by ID
 * @param {number} id - Visitor ID
 * @returns {Promise} API response
 */
export const deleteVisitor = async (id) => {
  try {
    const response = await apiClient.delete(`/api/admin/visitors/${id}`);
    return { success: true, data: response.data };
  } catch (error) {
    console.error('Error deleting visitor:', error);
    return {
      success: false,
      error: error.response?.data?.message || 'Failed to delete visitor.',
    };
  }
};

/**
 * Get dashboard statistics
 * @returns {Promise} API response with stats
 */
export const getDashboardStats = async () => {
  try {
    const response = await apiClient.get('/api/admin/dashboard/stats');
    return { success: true, data: response.data };
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return {
      success: false,
      error: error.response?.data?.message || 'Failed to fetch dashboard statistics.',
    };
  }
};

export default apiClient;
